# Hello, world!
#
# This is an example function named 'hello'
# which prints 'Hello, world!'.
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Build and Reload Package:  'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'

SCC_filtration <- function(data,celltype)
{

  pca<-prcomp(t(data))
  pcadata<-pca$x
  dis<-matrix(nrow=ncol(data),ncol=2)
  dis[,1]<-pcadata[,1]
  dis[,2]<-pcadata[,2]
  neardis<-dist(dis,p=2)
  dismatrix<-matrix(nrow=ncol(data),ncol=ncol(data))
  k<-1
  for (i in 1:(ncol(data)-1))
  {
    for (j in (i+1):ncol(data))
    {
      dismatrix[j,i]<-neardis[k]
      dismatrix[i,j]<-neardis[k]
      k<-k+1
    }
  }
  for (i in 1:ncol(data)) dismatrix[i,i]<-1000000
  nearnode<-rep(0,ncol(data))
  nearnodedis<-rep(1000000,ncol(data))
  for (i in 1:ncol(data))
  {
    for (j in 1:ncol(data))
    {
      if (dismatrix[i,j]<nearnodedis[i])
      {
        nearnode[i]<-j
        nearnodedis[i]<-dismatrix[i,j]
      }
    }
  }
  sortdis<-sort(nearnodedis)
  q1<-floor(length(sortdis)/4)
  q3<-length(sortdis)-q1
  maxdis<-sortdis[q3]+1.5*(sortdis[q3]-sortdis[q1])
  for (i in 1:ncol(data))
  {
    if (nearnodedis[i]>maxdis)
    {
      data<-data[,-i]
      celltype<-celltype[-i]
    }
  }

  result<-list(data,celltype)
  result$data<-data
  result$celltype<-celltype
  return (result)
}

SCC <- function(data) {
  #SCmap
  library(SingleCellExperiment)
  library(scmap)
  library(mclust)
  sce <- SingleCellExperiment(assays = list(normcounts = as.matrix(data)))
  logcounts(sce) <- log2(normcounts(sce) + 1)

  rowData(sce)$feature_symbol <- rownames(sce)
  isSpike(sce, "ERCC") <- grepl("^ERCC-", rownames(sce))

  sce <- sce[!duplicated(rownames(sce)), ]
  sce <- selectFeatures(sce, suppress_plot = FALSE)
  set.seed(1)
  sce <- indexCell(sce)
  sce <- indexCell(sce)
  scmapCell_results <- scmapCell(
    sce,
    list(
      data = metadata(sce)$scmap_cell_index
    )
    ,w=20
  )

  #EM_algorithm
  cell<-scmapCell_results$data$cells
  sim<-scmapCell_results$data$similarities
  data1<-data
  for (i in 1:ncol(data))
  {
    print(i)
    maxsim<-0
    for (j in 1:nrow(cell))
    {
      if (sim[j,i]>maxsim)
        maxsim<-sim[j,i]
    }
    nodenum<-0
    for (j in 1:nrow(cell))
    {
      if (sim[j,i]>(maxsim-0.1))
      {
        nodenum<-nodenum+1
      }
    }
    if (nodenum==1) {next}
    clustermatrix<-matrix(nrow=nrow(data),ncol=nodenum)
    node_i<-0
    for (j in 1:nrow(cell))
    {
      if (sim[j,i]>(maxsim-0.1))
      {
        node_i<-node_i+1



        clustermatrix[,node_i]<-data1[,cell[j,i]]
      }
    }
    #EM_algorithm for every gene
    for (gene in 1:nrow(data))
    {
      #deal zero values
      if (sum(clustermatrix[gene,])==0) {next}
      n<-nodenum
      m<-3
      miu<-mean(clustermatrix[gene,])
      sigma<-sqrt(var(clustermatrix[gene,]))
      if (is.na(sigma)||sigma==0) {next}
      num<-round(sample(1:10,1))
      p<-0.1
      alpha<-c(1/3,1/3,1/3)
      prob<-matrix(rep(0,n*m),ncol=m)
      #Iteration 100 times
      for (stepnum in 1:100)
      {
        #E sep
        for (j in 1:m)
        {
          if (j==1)
            prob[,j]<-sapply(clustermatrix[gene,],dnorm,miu,sigma)
          else if (j==2)
            prob[,j]<-dbinom(round(clustermatrix[gene,]),num,p)
          else
          {
            for (k in 1:nodenum)
            {
              if (clustermatrix[gene,k]==0) prob[k,j]<-1
              else prob[k,j]<-0
            }
          }
        }
        sumprob<-rowSums(prob)
        #deal with zero
        for (rownum in 1:n)
        {
          if (sumprob[rownum]==0)
            prob[rownum,]<-1/3
          else
            prob[rownum,]<-prob[rownum,]/sumprob[rownum]
        }
        oldmiu<-miu
        oldsigma<-sigma
        oldnum<-num
        oldp<-p
        oldalpha<-alpha
        #M step
        for (j in 1:m)
        {
          if (j==1)
          {
            p1<-sum(prob[,j])
            p2<-sum(prob[,j]*clustermatrix[gene,])
            miu<-p2/p1
            alpha[j]<-p1/n
            p3<-sum(prob[,j]*(clustermatrix[gene,]-miu)^2)
            sigma<-sqrt(p3/p1)
          }
          else if (j==2)
          {
            p1<-sum(prob[,j])
            p2<-sum(prob[,j]*clustermatrix[gene,])
            p3<-sum(prob[,j]*(clustermatrix[gene,]-p2/p1)^2)
            if (p2==0)
              p<-0
            else
              p<-1-p3/p2
            while(p<=0) p<-runif(1)
            num<-round(p2/(p1*p))
            alpha[j]<-p1/n
          }
          else
          {
            p1<-sum(prob[,j])
            alpha[j]<-p1/n
          }
        }
        #Termination Conditions
        if (prod(miu)==0||prod(sigma)==0||prod(alpha)==0) break
        epsilo<-1e-3
        if (sum(abs(miu-oldmiu))<epsilo&sum(abs(sigma-oldsigma))<epsilo&sum(abs(alpha-oldalpha))<epsilo) break
      }

      if (alpha[2]>1/3)
      {
        data[gene,i]<-num*p
      }
      else if(alpha[3]>1/3)
      {
        data[gene,i]<-0
      }
    }
  }
  return (data)
  write.table(data,"./modified_data.csv",row.names=TRUE,col.names=TRUE,sep=",")
}
